/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapp;

/**
 *
 * @author MSI
 */
public class getData {
    public  static  String Username;
    public  static  String part;
    
}
